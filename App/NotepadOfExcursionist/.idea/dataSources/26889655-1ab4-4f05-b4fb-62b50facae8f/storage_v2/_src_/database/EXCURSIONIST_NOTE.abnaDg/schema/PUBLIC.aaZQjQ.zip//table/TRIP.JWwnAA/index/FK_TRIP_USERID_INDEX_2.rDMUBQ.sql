create index FK_TRIP_USERID_INDEX_2
    on TRIP (USERID);

